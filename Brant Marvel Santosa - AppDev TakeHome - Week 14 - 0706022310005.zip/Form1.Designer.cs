﻿namespace Practice_SQL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_matchid = new System.Windows.Forms.TextBox();
            this.CB_teamhome = new System.Windows.Forms.ComboBox();
            this.CB_teamaway = new System.Windows.Forms.ComboBox();
            this.DGV_match = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.CB_type = new System.Windows.Forms.ComboBox();
            this.CB_player = new System.Windows.Forms.ComboBox();
            this.CB_team = new System.Windows.Forms.ComboBox();
            this.TB_minute = new System.Windows.Forms.TextBox();
            this.button_add = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_insert = new System.Windows.Forms.Button();
            this.dateTimePicker_match = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_match)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Match ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Team Home";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(670, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Team Away";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(670, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Match Date";
            // 
            // TB_matchid
            // 
            this.TB_matchid.Location = new System.Drawing.Point(167, 39);
            this.TB_matchid.Name = "TB_matchid";
            this.TB_matchid.Size = new System.Drawing.Size(180, 26);
            this.TB_matchid.TabIndex = 4;
            // 
            // CB_teamhome
            // 
            this.CB_teamhome.FormattingEnabled = true;
            this.CB_teamhome.Location = new System.Drawing.Point(167, 102);
            this.CB_teamhome.Name = "CB_teamhome";
            this.CB_teamhome.Size = new System.Drawing.Size(180, 28);
            this.CB_teamhome.TabIndex = 5;
            this.CB_teamhome.SelectedIndexChanged += new System.EventHandler(this.CB_teamhome_SelectedIndexChanged);
            // 
            // CB_teamaway
            // 
            this.CB_teamaway.FormattingEnabled = true;
            this.CB_teamaway.Location = new System.Drawing.Point(790, 99);
            this.CB_teamaway.Name = "CB_teamaway";
            this.CB_teamaway.Size = new System.Drawing.Size(180, 28);
            this.CB_teamaway.TabIndex = 7;
            this.CB_teamaway.SelectedIndexChanged += new System.EventHandler(this.CB_teamaway_SelectedIndexChanged);
            // 
            // DGV_match
            // 
            this.DGV_match.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_match.Location = new System.Drawing.Point(55, 172);
            this.DGV_match.Name = "DGV_match";
            this.DGV_match.RowHeadersWidth = 62;
            this.DGV_match.RowTemplate.Height = 28;
            this.DGV_match.Size = new System.Drawing.Size(660, 407);
            this.DGV_match.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(760, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Team";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(760, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 20);
            this.label6.TabIndex = 9;
            this.label6.Text = "Minute";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(760, 376);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "Type";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(760, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 20);
            this.label8.TabIndex = 11;
            this.label8.Text = "Player";
            // 
            // CB_type
            // 
            this.CB_type.FormattingEnabled = true;
            this.CB_type.Location = new System.Drawing.Point(836, 375);
            this.CB_type.Name = "CB_type";
            this.CB_type.Size = new System.Drawing.Size(180, 28);
            this.CB_type.TabIndex = 14;
            // 
            // CB_player
            // 
            this.CB_player.FormattingEnabled = true;
            this.CB_player.Location = new System.Drawing.Point(836, 313);
            this.CB_player.Name = "CB_player";
            this.CB_player.Size = new System.Drawing.Size(180, 28);
            this.CB_player.TabIndex = 13;
            // 
            // CB_team
            // 
            this.CB_team.FormattingEnabled = true;
            this.CB_team.Location = new System.Drawing.Point(836, 258);
            this.CB_team.Name = "CB_team";
            this.CB_team.Size = new System.Drawing.Size(180, 28);
            this.CB_team.TabIndex = 16;
            this.CB_team.SelectedIndexChanged += new System.EventHandler(this.CB_team_SelectedIndexChanged);
            // 
            // TB_minute
            // 
            this.TB_minute.Location = new System.Drawing.Point(836, 195);
            this.TB_minute.Name = "TB_minute";
            this.TB_minute.Size = new System.Drawing.Size(180, 26);
            this.TB_minute.TabIndex = 15;
            // 
            // button_add
            // 
            this.button_add.Location = new System.Drawing.Point(790, 455);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(75, 28);
            this.button_add.TabIndex = 17;
            this.button_add.Text = "Add";
            this.button_add.UseVisualStyleBackColor = true;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // button_delete
            // 
            this.button_delete.Location = new System.Drawing.Point(941, 455);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(75, 28);
            this.button_delete.TabIndex = 18;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_insert
            // 
            this.button_insert.Location = new System.Drawing.Point(656, 600);
            this.button_insert.Name = "button_insert";
            this.button_insert.Size = new System.Drawing.Size(161, 28);
            this.button_insert.TabIndex = 19;
            this.button_insert.Text = "Insert";
            this.button_insert.UseVisualStyleBackColor = true;
            this.button_insert.Click += new System.EventHandler(this.button_insert_Click);
            // 
            // dateTimePicker_match
            // 
            this.dateTimePicker_match.Location = new System.Drawing.Point(790, 39);
            this.dateTimePicker_match.Name = "dateTimePicker_match";
            this.dateTimePicker_match.Size = new System.Drawing.Size(301, 26);
            this.dateTimePicker_match.TabIndex = 20;
            this.dateTimePicker_match.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1345, 640);
            this.Controls.Add(this.dateTimePicker_match);
            this.Controls.Add(this.button_insert);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.button_add);
            this.Controls.Add(this.CB_team);
            this.Controls.Add(this.TB_minute);
            this.Controls.Add(this.CB_type);
            this.Controls.Add(this.CB_player);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DGV_match);
            this.Controls.Add(this.CB_teamaway);
            this.Controls.Add(this.CB_teamhome);
            this.Controls.Add(this.TB_matchid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_match)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_matchid;
        private System.Windows.Forms.ComboBox CB_teamhome;
        private System.Windows.Forms.ComboBox CB_teamaway;
        private System.Windows.Forms.DataGridView DGV_match;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox CB_type;
        private System.Windows.Forms.ComboBox CB_player;
        private System.Windows.Forms.ComboBox CB_team;
        private System.Windows.Forms.TextBox TB_minute;
        private System.Windows.Forms.Button button_add;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_insert;
        private System.Windows.Forms.DateTimePicker dateTimePicker_match;
    }
}

