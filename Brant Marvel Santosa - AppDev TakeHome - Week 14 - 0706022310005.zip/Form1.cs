﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using MySql.Data.MySqlClient;

namespace Practice_SQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;

        string sqlQuery;
        string sqlQuery2;
        string sqlQuery3;

        DataTable dtTim;
        DataTable dtteam1;
        DataTable dtteam2;

        DataTable player;
        DataTable dtdate;
        DataTable dgv;
        DataTable teamid;

        DataTable idplayer;
        string date;
        string temp;

        private void Form1_Load(object sender, EventArgs e)
        {
            dtTim = new DataTable();
            sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlQuery = "SELECT team_name FROM team";


            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTim);
            CB_teamhome.DataSource = dtTim;
            CB_teamhome.DisplayMember = "team_name";
            dtteam1 = new DataTable();
            sqlDataAdapter.Fill(dtteam1);

            CB_teamaway.DataSource = dtteam1;
            CB_teamaway.DisplayMember = "team_name";
            sqlConnect.Close();

            CB_teamhome.SelectedIndex = -1;
            CB_teamaway.SelectedIndex = -1;

            dgv = new DataTable();
            dgv.Columns.Add("Minute");
            dgv.Columns.Add("Team");
            dgv.Columns.Add("Player");
            dgv.Columns.Add("Type");
            dgv.Columns.Add("Team_ID");


            CB_type.Items.Add("GO");
            CB_type.Items.Add("GP");
            CB_type.Items.Add("GW");
            CB_type.Items.Add("CR");
            CB_type.Items.Add("CY");
            CB_type.Items.Add("PM");

        }

        private void CB_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {
            CB_team.Items.Clear();
            if (CB_teamhome.SelectedIndex == CB_teamaway.SelectedIndex)
            {
                MessageBox.Show("Select Another Team");
            }
            else
            {
                CB_team.Items.Add(CB_teamhome.Text);
                CB_team.Items.Add(CB_teamaway.Text);
            }
        }

        private void CB_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            CB_team.Items.Clear();
            if (CB_teamaway.SelectedIndex == CB_teamhome.SelectedIndex)
            {
                MessageBox.Show("Select Another Team");
            }
            else
            {
                CB_team.Items.Add(CB_teamhome.Text);
                CB_team.Items.Add(CB_teamaway.Text);
            }
        }

        private void CB_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            player = new DataTable();
            sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");

            sqlConnect.Open();
            sqlQuery = $"SELECT player.player_name FROM player, team WHERE player.team_id = team.team_id and team.team_name = '{CB_team.Text}' ;";

            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);

            sqlDataAdapter.Fill(player);
            CB_player.DataSource = player;
            CB_player.DisplayMember = "player_name";
            sqlConnect.Close();
            CB_player.SelectedIndex = -1;
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            dgv.Rows.Add(TB_minute.Text, CB_team.Text, CB_player.Text, CB_type.Text);
            DGV_match.DataSource = dgv;
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            dgv.Rows.RemoveAt(DGV_match.CurrentCell.RowIndex);
            DGV_match.DataSource = dgv;
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            foreach (DataRow data in dgv.Rows)
            {


                try
                {
                    teamid = new DataTable();
                    string sqlQuery4 = $"Select team_id FROM team WHERE team_name = '{data[1].ToString()}';";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery4, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);

                    sqlDataAdapter.Fill(teamid);
                    sqlConnect.Close();

                    idplayer = new DataTable();
                    string sqlQuery5 = $"Select player_id FROM player WHERE player_name = '{data[2].ToString()}';";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery5, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(idplayer);
                    sqlConnect.Close();
                    MessageBox.Show($"VALUES ('{TB_matchid.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{idplayer.Rows[0][0]}', '{data[3]}', '0')");


                    sqlQuery3 = $"INSERT INTO dmatch VALUES('{TB_matchid.Text}', '{data[0]}', '{teamid.Rows[0][0]}', '{idplayer.Rows[0][0]}', '{data[3]}', '0');";
                    sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");


                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery3, sqlConnect);
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dtdate = new DataTable();
            TB_matchid.Text = dateTimePicker_match.Value.Year.ToString();
            try
            {
                sqlQuery2 = $"SELECT COUNT(match_id) FROM `match` WHERE match_id LIKE '{dateTimePicker_match.Value.Year}%'";
                sqlConnect = new MySqlConnection("server=localhost;username=root;password=isbmantap;database=premier_league");
                sqlConnect.Open();


                sqlCommand = new MySqlCommand(sqlQuery2, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtdate);
                int total = Convert.ToInt32(dtdate.Rows[0][0]) + 1;
                if (total < 0)
                {
                    temp = $"{dateTimePicker_match.Value.Year}00{total}";

                }
                else if (total < 100)
                {
                    temp = $"{dateTimePicker_match.Value.Year}0{total}";

                }
                else
                {
                    temp = $"{dateTimePicker_match.Value.Year}{total}";

                }
                TB_matchid.Text = temp;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void dgvPremierLeague_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

